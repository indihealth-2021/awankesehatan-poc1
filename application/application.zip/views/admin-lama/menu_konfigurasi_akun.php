
    <!-- Main content -->
          <div class="page-wrapper">
            <div class="content">
              <div class="row">
                <div class="col-lg-6 col-12">
                  <!-- small box -->
                  <div class="small-box bg-info">
                  <a href="<?php echo base_url('admin/KonfigurasiAkun/form_username') ?>">
                    <div class="inner" style="padding: 13px">
                      <h3>Username</h3>
                      <p>Pengaturan</p>
                    </div>
                    <div class="icon">
                      <i class="fa fa-user"></i>
                    </div>
                    </a>
                    <a href="<?php echo base_url('admin/KonfigurasiAkun/form_username') ?>" class="small-box-footer">Ganti <i class="fas fa-arrow-circle-right"></i></a>
                  </div>
                </div>
                <!-- ./col -->
                <div class="col-lg-6 col-12">
                  <!-- small box -->
                  <div class="small-box bg-success">
                  <a href="<?php echo base_url('admin/KonfigurasiAkun/form_password') ?>">
                    <div class="inner" style="padding: 13px">
                      <h3>Password</h3>
                      <p>Pengaturan</p>
                    </div>
                    <div class="icon">
                      <i class="fa fa-lock"></i>
                    </div>
                    </a>
                    <a href="<?php echo base_url('admin/KonfigurasiAkun/form_password') ?>" class="small-box-footer">Ganti <i class="fas fa-arrow-circle-right"></i></a>
                  </div>
                </div>
            </div>
          </div>
    </div> 
