
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-lg-6 col-6">
            <!-- small box -->
            <a href="<?php echo base_url('pasien/KonfigurasiAkun/form_username') ?>">
            <div class="small-box card-menu bg-dark-blue-menu pd-card-menu">
              <div class="inner">
                <h5 class="text-white">Username</h5>
              </div>
              <div class="icon">
                <i class="fas fa-user"></i>
              </div>
            </div></a>
          </div>
          <!-- ./col -->
          <div class="col-lg-6 col-6">
            <!-- small box -->
            <a href="<?php echo base_url('pasien/KonfigurasiAkun/form_password') ?>">
            <div class="small-box card-menu bg-dark-blue-menu pd-card-menu">
              <div class="inner">
                <h5 class="text-white">Password</h5>
              </div>
              <div class="icon">
                <i class="fas fa-lock"></i>
              </div>
            </div>
            </a>
          </div>
        </div>
        <!-- </div> -->
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section> 
