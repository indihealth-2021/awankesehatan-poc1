<!-- Main content -->
<div class="page-wrapper">
    <div class="content">
        <div class="row mb-3">
            <div class="col-sm-12 col-12 ">
                <nav aria-label="">
                    <ol class="breadcrumb" style="background-color: transparent;">
                        <li class="breadcrumb-item active"><a href="<?php echo base_url('pasien/pasien'); ?>" class="text-black">Dashboard</a></li>
                        <li class="breadcrumb-item" aria-current="page"><a href="<?php echo base_url('pasien/Pendaftaran?poli=&hari=all') ?>" class="text-black font-bold-7">Pendaftaran</a></li>
                    </ol>
                </nav>
            </div>
            <div class="col-sm-12 col-12">
                <h3 class="page-title">Pendaftaran</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 col-12" style="float: right">

            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="bg-tab p-3">

                    <div class="row mb-3">
                        <div class="col-md-3 mx-3">
                            <div class="box">
                                <div class="container-1 ">
                                    <span class="icon"><i class="fa fa-search font-16"></i></span>
                                    <input type="search" id="search" placeholder="Cari Dokter Disini" />
                                </div>
                            </div>
                        </div>

                        <form method="GET" action="https://telemedicinelintasdev.indihealth.com/pasien/Pendaftaran"></form>
                        <div class="col-md-3">
                            <select class="form-control form-control-select" name="hari" id="hari" onchange="hari_onchange();">
                                <?php $hari = $this->input->get('hari') ?>
                                <option value="all" <?php echo $hari == 'all' ? 'selected' : '' ?>>Semua Hari</option>
                                <option value="Senin" <?php echo $hari == 'Senin' ? 'selected' : '' ?>>Senin</option>
                                <option value="Selasa" <?php echo $hari == 'Selasa' ? 'selected' : '' ?>>Selasa</option>
                                <option value="Rabu" <?php echo $hari == 'Rabu' ? 'selected' : '' ?>>Rabu</option>
                                <option value="Kamis" <?php echo $hari == 'Kamis' ? 'selected' : '' ?>>Kamis</option>
                                <option value="Jum'at" <?php echo $hari == "Jum'at" ? 'selected' : '' ?>>Jum'at</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <select class="form-control form-control-select" id="poli" name="poli" onchange="poli_onchange();">
                                <option value="" <?php $s = $this->input->get('poli') ? 'selected' : '';
                                                    echo $s; ?>>Semua Poli</option>
                                <?php
                                foreach ($data_poli as $poli) {
                                    $s = $this->input->get('poli') == $poli->poli ? 'selected' : '';
                                    echo "<option value='" . $poli->poli . "'" . $s . ">" . $poli->poli . "</option>";
                                }
                                ?>
                            </select>
                        </div>
                    </div>

                    <!-- <table cellspacing="5" cellpadding="5" border="0">
                        <tbody>
                            <form method="GET" action="https://telemedicinelintasdev.indihealth.com/pasien/Pendaftaran"></form>
                            <tr>
                                <td>
                                    <select class="form-control form-control-sm" name="hari" id="hari" onchange="hari_onchange();">
                                        <?php $hari = $this->input->get('hari') ?>
                                        <option>Pilih Hari</option>
                                        <option value="all" <?php echo $hari == 'all' ? 'selected' : '' ?>>Semua Hari</option>
                                        <option value="Senin" <?php echo $hari == 'Senin' ? 'selected' : '' ?>>Senin</option>
                                        <option value="Selasa" <?php echo $hari == 'Selasa' ? 'selected' : '' ?>>Selasa</option>
                                        <option value="Rabu" <?php echo $hari == 'Rabu' ? 'selected' : '' ?>>Rabu</option>
                                        <option value="Kamis" <?php echo $hari == 'Kamis' ? 'selected' : '' ?>>Kamis</option>
                                        <option value="Jum'at" <?php echo $hari == "Jum'at" ? 'selected' : '' ?>>Jum'at</option>
                                    </select>
                                </td>
                                <td>
                                    <select class="form-control form-control-sm" id="poli" name="poli" onchange="poli_onchange();">
                                        <option>Pilih Poli</option>
                                        <option value="" <?php $s = $this->input->get('poli') ? 'selected' : '';
                                                            echo $s; ?>>Semua</option>
                                        <?php
                                        foreach ($data_poli as $poli) {
                                            $s = $this->input->get('poli') == $poli->poli ? 'selected' : '';
                                            echo "<option value='" . $poli->poli . "'" . $s . ">" . $poli->poli . "</option>";
                                        }
                                        ?>
                                    </select>
                                </td>

                                <td>
                            <a href="https://telemedicinelintasdev.indihealth.com/pasien/JadwalTerdaftar" class="btn btn-sm btn-primary">Cek Jadwal Terdaftar</a>
                        </td>

                            </tr>
                        </tbody>
                    </table> -->
                    <div class="table-responsive">
                        <table class="table table-border table-hover custom-table mb-0" id="table_pendaftaran">
                            <thead class="text-tr">
                                <tr>
                                    <th class="text-left">No</th>
                                    <th>Dokter</th>
                                    <th>Poli</th>
                                    <th>Nominal</th>
                                    <th>Hari</th>
                                    <th>Waktu</th>
                                    <th>Tanggal</th>
                                    <th class="text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody class="font-14">
                                <?php
                                if (count($list_jadwal_dokter) > 0) {
                                    foreach ($list_jadwal_dokter as $idx => $jadwal_dokter) {
                                        $foto = $jadwal_dokter['foto_dokter'] ? base_url('assets/images/users/' . $jadwal_dokter['foto_dokter']) : base_url('assets/dashboard/img/user.jpg');
                                        $button = "<td class='text-center'><a class='btn btn-pilih' onclick=\"openModalAndRedirect('" . base_url('pasien/Pendaftaran/daftar?id_jadwal=' . $jadwal_dokter['id'] . '&token=' . $this->session->userdata("_token")) . "','spinner-".$jadwal_dokter['id']."')\"><i style='display:none;' id='spinner-".$jadwal_dokter['id']."' class='fa fa-spinner fa-spin'></i>&nbsp;Pilih</a></td>";
                                        $nominal = $this->db->query('SELECT harga FROM nominal WHERE poli = "' . $jadwal_dokter["poli"] . '"')->row();
                                        echo "<tr>";
                                        echo "<td>" . ($idx + 1) . "</td>";
                                        echo "<td><img width='34' height='34' src=" . $foto . " class='rounded-circle m-r-5' alt=''><div class='ml-5' style='margin-top:-30px'>" . ucwords($jadwal_dokter['nama_dokter']) . "</div></td>";
                                        echo "<td>" . $jadwal_dokter["poli"] . "</td>";
                                        echo "<td>" . 'Rp ' . number_format($nominal->harga, 2, ',', '.') . "</td>";
                                        echo "<td>" . ucwords($jadwal_dokter['hari']) . "</td>";
                                        echo "<td>" . $jadwal_dokter['waktu'] . "</td>";
                                        $jadwal_dokter['tanggal'] = $jadwal_dokter['tanggal'] ? (new DateTime($jadwal_dokter['tanggal']))->format('d-m-Y') : 'Jadwal Rutin';
                                        echo "<td>" . $jadwal_dokter['tanggal'] . "</td>";
                                        echo $button;
                                        echo "</tr>";
                                    }
                                }
                                ?>
                                <!-- <tr>
                                        <td>1</td>
                                        <td><img width="28" height="28" src="<?php echo base_url('assets/dashboard/img/user.jpg'); ?>" class="rounded-circle m-r-5" alt="">Dokter</td>
                                        <td>ANAK</td>
                                        <td>Rp. 100.000,00</td>
                                        <td>Senin</td>
                                        <td>10:00 AM - 7:00 PM</td>
                                        <td>09-11-2020</td>
                                        <td class="text-center"><a href="" type="button" class="btn btn-primary btn-sm"><i class="fa fa-check-circle"></i> Pilih</a></td>
                                    </tr> -->
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="modal fade" id="tac_modal_daftar" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-scrollable" role="document" style="">
                        <div class="modal-content" style="height: 600px;">
                            <div class="modal-header text-modal-header">
                                <h5 class="modal-title font-16" id="exampleModalScrollableTitles">SYARAT DAN KETENTUAN PENGGUNAAN</h5>
                            </div>
                            <div class="modal-body">
                                <div class="font-16 text-justify" style="overflow-y: scroll; max-height: 400px; padding: 5px;" id="toc_body">
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:center;vertical-align:baseline;'><strong><span style='font-size:15px;font-family:"Calibri",sans-serif;'>SYARAT DAN KETENTUAN PENGGUNAAN</span></strong></p>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:center;vertical-align:baseline;'><strong><span style='font-size:15px;font-family:"Calibri",sans-serif;'>SI TUNTAS</span></strong></p>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:center;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><em><span style='font-size:15px;font-family:"Calibri",sans-serif;'>MOHON UNTUK MEMBACA SELURUH SYARAT DAN KETENTUAN PENGGUNAAN SERTA KEBIJAKAN PRIVASI YANG TERLAMPIR DENGAN CERMAT DAN SAKSAMA SEBELUM MENGGUNAKAN SETIAP FITUR DAN/ATAU LAYANAN YANG TERSEDIA DALAM PLATFORM SI TUNTAS.</span></em></p>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>Syarat dan Ketentuan Penggunaan (&ldquo;<strong><span style='font-family:"Calibri",sans-serif;'>Ketentuan Penggunaan</span></strong>&rdquo;) ini merupakan suatu perjanjian sah terkait tata cara dan persyaratan penggunaan fitur dan/atau layanan (&ldquo;<strong><span style='font-family:"Calibri",sans-serif;'>Layanan</span></strong>&rdquo;) Platform SI TUNTAS &nbsp;(&ldquo;<strong><span style='font-family:"Calibri",sans-serif;'>Platform</span></strong>&rdquo;) antara Pengguna (&ldquo;<strong><span style='font-family:"Calibri",sans-serif;'>Anda</span></strong>&rdquo;) dengan pengelola Platform, yaitu Rumah Sakit &hellip;&hellip;&hellip;. yang didukung oleh PT. Aplikanusa Lintasarta (&ldquo;<strong><span style='font-family:"Calibri",sans-serif;'>Kami</span></strong>&rdquo;). Dengan mengunduh dan/atau memasang dan/atau menggunakan Platform dan/atau menikmati Layanan Kami, Anda setuju bahwa Anda telah membaca, memahami, mengetahui, menerima, dan menyetujui seluruh informasi, syarat-syarat, dan ketentuan-ketentuan penggunaan Platform yang terdapat dalam Ketentuan Penggunaan ini.&nbsp;</span></p>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>Apabila Anda tidak setuju terhadap salah satu, sebagian, atau seluruh isi yang tertuang dalam Ketentuan Penggunaan dan Kebijakan Privasi ini, silakan untuk menghapus Platform dalam perangkat elektronik Anda dan/atau tidak mengakses Platform dan/atau tidak menggunakan Layanan Kami. Mohon untuk dapat diperhatikan pula bahwa Ketentuan Penggunaan dan Kebijakan Privasi dapat diperbarui dari waktu ke waktu.</span></p>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <div style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'>
                                        <ol style="margin-bottom:0cm;list-style-type: decimal;margin-left:8px;">
                                            <li style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><span style='font-family:"Calibri",sans-serif;'>KETENTUAN UMUM</span></li>
                                        </ol>
                                    </div>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <ol start="1" style="list-style-type: lower-alpha;margin-left:26px;">
                                        <li><span style='font-family:"Calibri",sans-serif;'>Platform adalah aplikasi (versi Android), aplikasi web (aplikasi yang dapat diakses menggunakan web), website yang dikelola oleh Kami sebagaimana diperbarui dari waktu ke waktu.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Koneksi internet diperlukan untuk dapat menggunakan Layanan dan biaya terkait penggunaan koneksi internet tersebut ditanggung sepenuhnya oleh Anda.&nbsp;</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Platform berfungsi sebagai sarana untuk menghubungkan Anda dengan pihak Rumah Sakit yang menyediakan layanan atau menjual barang kepada Anda seperti (tetapi tidak terbatas pada) dokter, psikolog, apotek, laboratorium, dan/atau jasa pengantaran (&ldquo;<strong><span style='font-family:"Calibri",sans-serif;'>Penyedia Layanan</span></strong>&rdquo;).</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Jenis layanan yang dapat digunakan melalui Platform adalah:</span></li>
                                    </ol>
                                    <ul style="list-style-type: disc;margin-left:44px;">
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>Pendaftaran online untuk telekonsultasi dengan dokter RS;</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>Pembayaran menggunakan asuransi Owlexa maupun pembayaran elektronik untuk non-asuransi</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>Video call dan Chat dengan Dokter;</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>Pemberian resep dan pengiriman obat;</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>Layanan lain yang dapat kami tambahkan dari waktu ke waktu;</span></li>
                                    </ul>
                                    <ol start="5" style="list-style-type: lower-alpha;margin-left:26px;">
                                        <li><span style='font-family:"Calibri",sans-serif;'>Kami dapat menggunakan jasa pihak ketiga terkait penyediaan layanan pembayaran. Apabila terjadi kegagalan pada sistem pembayaran, Kami akan berupaya semaksimal mungkin dalam membantu menyelesaikan masalah yang mungkin timbul. Penyedia jasa perbankan/pembayaran yang dipilih oleh Anda dapat mengenakan biaya tambahan kepada Anda atas layanan yang diberikan.&nbsp;</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>Setiap fitur atau fasilitas dalam Platform dapat diperbarui atau diubah sesuai dengan kebutuhan dan perkembangan Platform.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Informasi mengenai data pribadi dan riwayat kesehatan anda tersimpan di dalam database milik RS, dan Kami akan menyimpan serta menampilkannya dalam akun Anda. Kerahasiaan data Anda terjamin dan akan digunakan oleh Rumah Sakit untuk keperluan interaksi dengan dokter dan/atau keperluan pemesanan obat serta layanan lainnya yang dilakukan di dalam Platform yang telah Anda setujui sesuai dengan ketentuan perundang-undangan yang berlaku dan Kebijakan Privasi.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Dengan menggunakan Platform, Anda memahami dan menyetujui bahwa percakapan melalui fitur <em><span style='font-family:"Calibri",sans-serif;'>video call</span></em>, <em><span style='font-family:"Calibri",sans-serif;'>voice call</span></em> maupun <em><span style='font-family:"Calibri",sans-serif;'>chat</span></em> akan tersimpan secara otomatis dan diarsipkan untuk keperluan legal dan peningkatan kualitas layanan. Kerahasiaan percakapan Anda terjamin dan informasi tidak akan disebarluaskan.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>Anda memahami dan menyetujui bahwa komunikasi Anda dengan fasilitas pelayanan kesehatan yang terhubung tersimpan secara otomatis dan diarsipkan untuk keperluan legal dan peningkatan kualitas layanan. Kerahasiaan percakapan Anda terjamin dan informasi tidak akan disebarluaskan.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>Kami dapat menghentikan atau membatasi proses registrasi atau penggunaan Platform oleh Anda jika ditemukan pelanggaran dari Ketentuan Penggunaan ini atau peraturan perundang-undangan yang berlaku.</span></li>
                                    </ol>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <div style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'>
                                        <ol style="margin-bottom:0cm;list-style-type: undefined;margin-left:8px;">
                                            <li style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><span style='font-family:"Calibri",sans-serif;'>KETENTUAN PENGGUNAAN PLATFORM</span></li>
                                        </ol>
                                    </div>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <ol start="1" style="list-style-type: lower-alpha;margin-left:26px;">
                                        <li><span style='font-family:"Calibri",sans-serif;'>Anda menyatakan dan menjamin bahwa Anda adalah individu yang memiliki hak untuk mengadakan perjanjian yang mengikat berdasarkan hukum Negara Republik Indonesia dan bahwa Anda telah berusia minimal 21 (dua puluh satu) tahun atau sudah menikah dan tidak berada di bawah perwalian atau pengampuan. Jika Anda berusia di bawah 21 (dua puluh satu) tahun dan belum menikah, Anda menyatakan dan menjamin bahwa Anda telah memperoleh izin dari orang tua atau wali hukum Anda, kecuali Anda menyatakan sebaliknya.&nbsp;</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Dengan memberikan persetujuan, orang tua atau wali hukum Anda setuju untuk bertanggung jawab atas:&nbsp;</span></li>
                                    </ol>
                                    <ol style="list-style-type: lower-roman;margin-left:48.5px;">
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>semua tindakan Anda terkait akses ke dan penggunaan Platform dan/atau Layanan;&nbsp;</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>biaya apa pun terkait penggunaan Anda atas Layanan apa pun; dan&nbsp;</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>kepatuhan Anda terhadap Syarat dan Ketentuan ini.&nbsp;</span></li>
                                    </ol>
                                    <p style='margin-right:0cm;margin-left:40.5pt;font-size:16px;font-family:"Times New Roman",serif;margin-top:0cm;margin-bottom:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>Kami dapat menutup atau membatalkan akun Anda apabila hal tersebut tidak benar. Anda selanjutnya menyatakan dan menjamin bahwa Anda memiliki hak, wewenang dan kapasitas untuk menggunakan Layanan dan akan senantiasa mematuhi Ketentuan Penggunaan. Jika Anda mendaftarkan atas nama suatu badan usaha, Anda juga menyatakan bahwa Anda berwenang untuk bertindak untuk dan atas nama badan hukum tersebut dan untuk mengadakan dan mengikatkan badan hukum/entitas tersebut pada Ketentuan Penggunaan Platform.&nbsp;</span></p>
                                    <ol start="3" style="list-style-type: lower-alpha;margin-left:26px;">
                                        <li><span style='font-family:"Calibri",sans-serif;'>Anda dapat menggunakan Platform dengan terlebih dahulu melakukan pendaftaran yang disertai pemberian informasi data pribadi Anda yang dapat dipertanggung jawabkan secara hukum sebagaimana diminta dalam Platform (&ldquo;Data Pribadi&rdquo;). Informasi terkait Data Pribadi yang diberikan hanya akan digunakan oleh Rumah Sakit untuk pemberian layanan-layanan dalam Platform dan untuk tujuan lain yang telah Anda setujui sesuai dengan ketentuan perundang-undangan yang berlaku. Kebijakan Privasi yang terlampir (sebagaimana diperbarui dari waktu ke waktu) menjadi bagian yang tidak terpisahkan dari Ketentuan Penggunaan ini.&nbsp;</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Setelah mendaftarkan diri pada Platform, Anda akan mendapatkan suatu link melalui email yang anda isikan dan menjadikan akun anda aktif. Kami harap Anda tidak menyerahkan, mengalihkan maupun memberikan wewenang kepada orang lain untuk menggunakan identitas atau menggunakan akun Anda. Anda wajib menjaga kerahasiaan kata sandi akun Anda dan setiap identifikasi yang kami berikan kepada Anda atas akun atau Data Pribadi Anda. Apabila terjadi pengungkapan atas kata sandi Anda yang terjadi bukan atas kesalahan Kami, dengan cara apapun yang mengakibatkan penggunaan yang tidak sah dan tanpa kewenangan atas akun atau Anda, transaksi maupun pesanan atas Layanan yang dilakukan melalui Platform masih akan dianggap sebagai transaksi yang sah kecuali apabila Anda telah memberitahu Kami tentang hal tersebut sebelum Penyedia Layanan memberikan Layanan yang diminta.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Anda memiliki tanggung jawab atas setiap penggunaan akun Anda dalam Platform. Apabila Anda tidak memiliki kontrol atas akun Anda oleh sebab apapun, maka Anda diharuskan untuk melaporkannya kepada Kami. Apabila terjadi penyalahgunaan akun Anda oleh orang lain sebelum pelaporan terjadi, maka penggunaan akun pada periode tersebut akan menjadi tanggung jawab Anda.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>Anda tidak diperkenankan untuk membahayakan, menyalahgunakan, mengubah atau memodifikasi Platform dengan cara apapun. Kami dapat menutup atau membatalkan akun Anda dan melarang Anda untuk menggunakan Platform lebih lanjut jika Anda tidak mematuhi Ketentuan Penggunaan ini.&nbsp;</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Dengan menggunakan Platform, maka Anda memahami, setuju, dan tunduk sesuai yang dipersyaratkan pada Kebijakan Privasi Kami sebagaimana berlaku dari waktu ke waktu.&nbsp;</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Anda akan menggunakan Platform hanya untuk tujuan mendapatkan Layanan, dan tidak akan &nbsp;menyalahgunakan atau menggunakan Platform untuk aktivitas yang bertentangan dengan hukum, termasuk namun tidak terbatas kepada tindak pidana pencucian uang, pencurian, penggelapan, terorisme maupun penipuan. Anda juga sepakat bahwa Anda tidak akan melakukan pemesanan palsu melalui Platform dan tidak akan melakukan perbuatan melawan hukum melalui Platform.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>Dengan memberikan informasi kepada Kami, Anda menyatakan bahwa Anda setuju bahwa informasi yang Anda berikan akan digunakan oleh Rumah Sakit.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>Anda mengetahui dan setuju bahwa setiap informasi dalam bentuk apapun, termasuk namun tidak terbatas pada video, audio, gambar atau tulisan yang ada dalam Platform memiliki hak atas kekayaan intelektual (termasuk namun tidak terbatas kepada hak atas merek dan hak cipta) masing-masing. Anda tidak diperbolehkan untuk menggunakan, mengubah, memfasilitasi, menyebarluaskan dan/atau memutilasi hak atas kekayaan intelektual tersebut tanpa izin dari pemilik hak atas kekayaan intelektual tersebut sebagaimana diatur dalam peraturan perundang-undangan yang berlaku.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Pada saat mengakses dan menggunakan Platform termasuk setiap fitur dan layanannya, Anda tidak diperkenankan untuk:</span>
                                            <ol style="list-style-type: lower-roman;">
                                                <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>mengalihkan akun Anda di Platform kepada pihak lain tanpa persetujuan terlebih dahulu dari Kami.</span></li>
                                                <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>menyebarkan virus, spam atau teknologi sejenis lainnya yang dapat merusak dan/atau merugikan Platform dan pengguna Platform lainnya.</span></li>
                                                <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>memasukkan atau memindahkan fitur pada Platform tanpa persetujuan dari Kami.</span></li>
                                                <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>menempatkan informasi atau aplikasi lain yang melanggar hak kekayaan intelektual pihak lain di dalam Platform.</span></li>
                                                <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>mengambil atau mengumpulkan data pribadi dari pengguna Platform lain, termasuk tetapi tidak terbatas pada alamat surel, tanpa persetujuan dari pengguna tersebut.</span></li>
                                                <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>menggunakan Platform untuk hal-hal yang dilarang berdasarkan hukum dan undang-undang yang berlaku.</span></li>
                                                <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>menggunakan Platform untuk mendistribusikan iklan atau materi lainnya.</span></li>
                                            </ol>
                                        </li>
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>Anda mengetahui dan menyetujui bahwa tarif Layanan yang tercantum pada Platform dapat mengalami perubahan.</span></li>
                                    </ol>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <div style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'>
                                        <ol style="margin-bottom:0cm;list-style-type: undefined;margin-left:8px;">
                                            <li style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><span style='font-family:"Calibri",sans-serif;'>LAYANAN</span></li>
                                        </ol>
                                    </div>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <ol start="1" style="list-style-type: lower-alpha;margin-left:26px;">
                                        <li><span style='font-family:"Calibri",sans-serif;'>Fitur ini memfasilitasi para dokter, psikolog, dan/atau psikolog klinis yang terdaftar pada Rumah Sakit dan memiliki SIP, untuk berinteraksi dengan Anda melalui <em><span style='font-family:"Calibri",sans-serif;'>video call</span></em>, <em><span style='font-family:"Calibri",sans-serif;'>voice call</span></em> maupun <em><span style='font-family:"Calibri",sans-serif;'>chat</span></em> yang dapat diakses melalui Aplikasi dan Website.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Anda tidak dapat membatalkan <em><span style='font-family:"Calibri",sans-serif;'>booking</span></em> Chat dengan dokter, psikolog, atau psikolog klinis Kami. JIka ingin membatalkan, anda dapat menolak panggilan dari dokter kami. Konsekuensi dari proses ini adalah tidak adanya pengembalian dana sesuai dengan prosedur yang berlaku.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Dokter, psikolog, atau psikolog klinis Kami dapat membatalkan <em><span style='font-family:"Calibri",sans-serif;'>booking&nbsp;</span></em>Chat maksimal 30 (tiga puluh) menit sebelum jadwal untuk berkonsultasi dimulai. Kami akan menawarkan untuk perubahan jadwal seperti pengunduran waktu telekonsultasi, atau mengganti nya dengan dokter lain sesuai dengan prosedur yang berlaku.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Jika Anda tidak hadir pada jadwal <em><span style='font-family:"Calibri",sans-serif;'>booking</span></em> yang telah Anda pilih maka Anda menyetujui bahwa dana yang telah Anda bayarkan tidak dapat dikembalikan.&nbsp;</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Kami akan mengirimkan pemberitahuan terkait janji Chat dengan Dokter melalui <em><span style='font-family:"Calibri",sans-serif;'>push notification</span></em> pada perangkat elektronik Anda. Untuk dapat menerima <em><span style='font-family:"Calibri",sans-serif;'>push notification</span></em> yang Kami kirimkan maka Anda harus mengaktifkan <em><span style='font-family:"Calibri",sans-serif;'>push notification</span></em> tersebut.&nbsp;</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>Anda mengetahui dan menyetujui bahwa fitur ini tidak menggantikan pemeriksaan dan pengobatan dengan dokter pada umumnya atau tatap muka secara langsung.&nbsp;</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Kami tidak menyarankan Anda menggunakan Platform untuk kondisi medis darurat.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Anda memahami bahwa Anda perlu memberikan informasi dan menjelaskan gejala atau keluhan fisik yang Anda alami secara lengkap, jelas dan akurat ketika melakukan percakapan dengan dokter rekanan Kami melalui fitur Chat dengan Dokter.</span></li>
                                    </ol>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <div style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'>
                                        <ol style="margin-bottom:0cm;list-style-type: undefined;margin-left:8px;">
                                            <li style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><span style='font-family:"Calibri",sans-serif;'>TRANSAKSI</span></li>
                                        </ol>
                                    </div>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <ol start="1" style="list-style-type: lower-alpha;margin-left:26px;">
                                        <li><span style='font-family:"Calibri",sans-serif;'>Untuk dapat bertransaksi di Platform, Anda dapat menggunakan berbagai metode pembayaran yang tersedia pada Platform.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Apabila Anda mencurigai adanya aktivitas yang tidak wajar dan/atau terjadi perselisihan/sengketa sehubungan dengan akun Anda, Anda dapat segera menghubungi Kami agar Kami dapat segera mengambil tindakan yang diperlukan.&nbsp;</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Kami dapat melakukan penangguhan segala transaksi yang berasal dari akun Anda serta dapat melakukan tindakan penangguhan transaksi apabila kami mengidentifikasi adanya masalah pada akun Anda atau suatu transaksi tertentu.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Anda memahami dan menyetujui bahwa batas waktu pengajuan keluhan mengenai transaksi adalah maksimal 7 (tujuh) hari kalender setelah transaksi selesai.</span></li>
                                    </ol>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <div style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'>
                                        <ol style="margin-bottom:0cm;list-style-type: undefined;margin-left:8px;">
                                            <li style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><span style='font-family:"Calibri",sans-serif;'>KETENTUAN TRANSAKSI</span></li>
                                        </ol>
                                    </div>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <div style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'>
                                        <ol start="1" style="margin-bottom:0cm;list-style-type: upper-alpha;margin-left:26px;">
                                            <li style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><span style='font-family:"Calibri",sans-serif;'>Fitur Video Call dan Chat dengan Dokter</span></li>
                                        </ol>
                                    </div>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <ol style="list-style-type: lower-roman;margin-left:35px;">
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>Anda akan dikenakan tarif dengan jumlah tertentu yang sudah di tentukan oleh pihak Rumah Sakit.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>Saat menghubungi dokter melalui <em><span style=";">chat</span></em>, Anda dapat mengirimkan gambar kepada dokter yang berkaitan dengan kondisi medis Anda dengan format png, jpg, dan bitmap.&nbsp;</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>Setelah sesi Chat dengan Dokter selesai, dokter dapat memberikan <em><span style='font-family:"Calibri",sans-serif;'>Diagnosa&nbsp;</span></em>dan <em><span style='font-family:"Calibri",sans-serif;'>Electronic Prescription</span></em>.&nbsp;</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>Dokter dapat melakukan <em><span style='font-family:"Calibri",sans-serif;'>Follow Up&nbsp;</span></em>kepada Anda untuk mengecek kondisi kesehatan Anda setelah dilakukannya sesi Chat dengan Dokter.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>Transaksi tidak dapat dibatalkan setelah sesi Chat dengan Dokter berakhir atau selesai dilakukan.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>Kami dapat memblokir atau membatalkan akun Anda apabila terdapat penyalahgunaan fitur Chat dengan Dokter pada akun Anda.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>Biaya yang dikenakan tersebut belum termasuk penggunaan pembayaran dengan metode : e-banking, m-banking..</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>Ketepatan serta keakuratan Dokter dalam memberikan <em><span style='font-family:"Calibri",sans-serif;'>Electronic Prescription&nbsp;</span></em>akan bergantung pada informasi yang diberikan oleh Anda. Setiap isi dan/atau pernyataan-pernyataan dalam percakapan yang dilakukan oleh Anda dengan Dokter menggunakan fitur <em><span style=";">video call, chat, Diagnosa</span></em>, <em><span style='font-family:"Calibri",sans-serif;'>Electronic Prescription</span></em>, pada Platform, hal tersebut ialah percakapan dan interaksi pribadi antara Anda dengan Dokter rekanan sebagai pemberi jasa layanan kesehatan.</span></li>
                                    </ol>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <div style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'>
                                        <ol style="margin-bottom:0cm;list-style-type: undefined;margin-left:8px;">
                                            <li style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><span style='font-family:"Calibri",sans-serif;'>HAK ATAS KEKAYAAN INTELEKTUAL</span></li>
                                        </ol>
                                    </div>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <ol start="1" style="list-style-type: lower-alpha;margin-left:26px;">
                                        <li><span style='font-family:"Calibri",sans-serif;'>Kami adalah pemilik atas nama, ikon, dan logo SI TUNTAS serta fitur Chat dengan Dokter, yang mana merupakan hak cipta dan merek dagang yang dilindungi undang-undang Republik Indonesia. Anda tidak dapat menggunakan, memodifikasi, atau memasang nama, ikon, logo, atau merek tersebut tanpa persetujuan tertulis dari Kami.&nbsp;</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Seluruh hak atas kekayaan intelektual yang terdapat dalam Platform berdasarkan hukum negara Republik Indonesia, termasuk dalam hal ini adalah kepemilikan hak kekayaan intelektual atas seluruh <em><span style='font-family:"Calibri",sans-serif;'>source code</span></em> Platform dan hak kekayaan intelektual terkait Platform. Untuk itu, Anda dilarang untuk melakukan pelanggaran atas hak kekayaan intelektual yang terdapat pada Platform ini, termasuk melakukan modifikasi, karya turunan, mengadaptasi, menduplikasi, menyalin, menjual, membuat ulang, meretas, menjual, dan/atau mengeksploitasi Platform termasuk penggunaan Platform atas akses yang tidak sah, meluncurkan program otomatis atau script, atau segala program apapun yang mungkin menghambat operasi dan/atau kinerja Platform, atau dengan cara apapun memperbanyak atau menghindari struktur navigasi atau presentasi dari Platform atau isinya.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Anda hanya diperbolehkan untuk menggunakan Platform semata-mata untuk kebutuhan pribadi dan tidak dapat dialihkan.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Kami dapat mengambil tindakan hukum terhadap setiap pelanggaran yang dilakukan oleh Anda terkait dengan hak kekayaan intelektual terkait Platform.</span></li>
                                    </ol>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <div style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'>
                                        <ol style="margin-bottom:0cm;list-style-type: undefined;margin-left:8px;">
                                            <li style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><span style='font-family:"Calibri",sans-serif;'>FUNGSI PLATFORM</span></li>
                                        </ol>
                                    </div>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <p style='margin-right:0cm;margin-left:18.0pt;font-size:16px;font-family:"Times New Roman",serif;margin-top:0cm;margin-bottom:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>Kami senantiasa melakukan upaya untuk menjaga Platform ini berfungsi dan berjalan lancar. Perlu diketahui bahwa Platform dan/atau fitur Layanan Kami dapat sewaktu-waktu tidak tersedia yang disebabkan oleh berbagai alasan, termasuk namun tidak terbatas pada keperluan pemeliharaan atau masalah teknis, dan situasi ini berada di luar kuasa kami.&nbsp;</span></p>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <div style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'>
                                        <ol style="margin-bottom:0cm;list-style-type: undefined;margin-left:8px;">
                                            <li style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><span style='font-family:"Calibri",sans-serif;'>PENUTUP</span></li>
                                        </ol>
                                    </div>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <ol start="1" style="list-style-type: lower-alpha;margin-left:26px;">
                                        <li><span style='font-family:"Calibri",sans-serif;'>Ketentuan Penggunaan ini diatur dan ditafsirkan serta dilaksanakan berdasarkan hukum yang berlaku di Negara Republik Indonesia dan Anda dengan tegas menyetujui bahwa bahwa ketentuan Pasal 1266 Kitab Undang-Undang Hukum Perdata dan ketentuan lainnya yang mewajibkan adanya pengesahan atau persetujuan pengadilan untuk dapat mengakhiri Ketentuan Penggunaan tidak berlaku terhadap Ketentuan Penggunaan ini.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Segala sengketa yang berkaitan dengan Ketentuan Penggunaan ini, diselesaikan secara musyawarah untuk mufakat atau melalui Badan Arbitrase Nasional Indonesia (BANI), sesuai dengan prosedur yang berlaku di BANI. Apabila kedua belah pihak tidak sepakat untuk menyelesaikannya sengketa di BANI, maka sengketa akan diselesaikan melalui Pengadilan Negeri Jakarta Selatan</span></li>
                                    </ol>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:center;vertical-align:baseline;'><strong><span style='font-size:15px;font-family:"Calibri",sans-serif;'>KEBIJAKAN PRIVASI</span></strong></p>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:center;vertical-align:baseline;'><strong><span style='font-size:15px;font-family:"Calibri",sans-serif;'>SI TUNTAS</span></strong></p>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>Kebijakan privasi ini (&ldquo;<strong><span style='font-family:"Calibri",sans-serif;'>Kebijakan Privasi</span></strong>&rdquo;) akan menjelaskan bagaimana Rumah sakit yang di dukung oleh PT. Aplikanusa Lintasarta serta perusahaan afiliasinya (&ldquo;<strong><span style='font-family:"Calibri",sans-serif;'>Kami</span></strong>&rdquo;), memperoleh, mengumpulkan, menggunakan, menampilkan, mengumumkan, mengungkapkan, memproses, membukakan akses, menyimpan, mengirim, memberi, mengalihkan, mengolah, mengelola, memusnahkan dan melindungi informasi dan data pribadi (secara bersama-sama, &ldquo;<strong><span style='font-family:"Calibri",sans-serif;'>Pemanfaatan</span></strong>&rdquo;) yang anda sebagai pengguna (&ldquo;<strong><span style='font-family:"Calibri",sans-serif;'>Anda</span></strong>&rdquo;) Platform (sebagaimana didefinisikan di bawah) berikan sebagaimana diminta maupun pada saat menggunakan Platform (&ldquo;<strong><span style='font-family:"Calibri",sans-serif;'>Data Pribadi</span></strong>&rdquo;). Perlu dicatat bahwa Data Pribadi di sini tidak termasuk Data Pribadi yang telah tersedia di domain publik.&nbsp;</span></p>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>Kebijakan Privasi ini merupakan bagian dari Syarat dan Ketentuan Penggunaan (&ldquo;<strong><span style='font-family:"Calibri",sans-serif;'>Ketentuan Penggunaan</span></strong>&rdquo;) Kami. Penggunaan Platform dan setiap fitur dan/atau layanan yang tersedia dalam Platform (&ldquo;<strong><span style='font-family:"Calibri",sans-serif;'>Layanan</span></strong>&rdquo;) merupakan bentuk persetujuan anda terhadap Ketentuan Penggunaan dan Kebijakan Privasi tersebut. Oleh karena itu, Anda perlu untuk membaca Kebijakan Privasi ini dengan saksama untuk memastikan bahwa Anda memahaminya sepenuhnya sebelum mendaftar, mengakses dan/atau menggunakan Platform dan Layanan Kami.&nbsp;</span></p>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <div style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'>
                                        <ol start="1" style="margin-bottom:0cm;list-style-type: upper-alpha;margin-left:8px;">
                                            <li style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><span style='font-family:"Calibri",sans-serif;'>Lingkup Kebijakan Privasi</span></li>
                                        </ol>
                                    </div>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <ol style="list-style-type: decimal;margin-left:26px;">
                                        <li><span style='font-family:"Calibri",sans-serif;'>Kebijakan Privasi ini mengatur Pemanfaatan Data Pribadi.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Dengan menggunakan Platform, maka Anda dianggap telah membaca Kebijakan Privasi ini dan menyetujui mekanisme Pemanfaatan Data Pribadi Anda sebagaimana diatur dalam Kebijakan Privasi ini.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Apabila Kami meminta Anda untuk memberikan informasi ketika menggunakan Platform, maka informasi tersebut itu hanya akan digunakan untuk keperluan pemberian Layanan sesuai dengan Kebijakan Privasi ini.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Kami berhak untuk sewaktu-waktu mengubah, menghapus dan untuk menerapkan ketentuan baru Kebijakan Privasi ini. Anda diharapkan untuk memeriksa halaman Kebijakan Privasi ini secara berkala untuk mengetahui perubahan tersebut. Dengan menggunakan Platform setelah terjadinya perubahan tersebut, Anda dianggap telah mengetahui dan menyetujui perubahan-perubahan ketentuan pada Kebijakan Privasi ini.</span></li>
                                    </ol>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <div style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'>
                                        <ol start="2" style="margin-bottom:0cm;list-style-type: upper-alpha;margin-left:8px;">
                                            <li style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><span style='font-family:"Calibri",sans-serif;'>Registrasi</span></li>
                                        </ol>
                                    </div>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <ol style="list-style-type: decimal;margin-left:26px;">
                                        <li><span style='font-family:"Calibri",sans-serif;'>Anda diharuskan melakukan pendaftaran dalam Platform untuk dapat menggunakan fitur &ndash; fitur pada Platform.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Untuk melakukan pendaftaran dalam Platform, Anda harus memberikan informasi yang Kami perlukan sebagaimana tercantum pada Poin C (Data Pribadi) di bawah ini.</span></li>
                                    </ol>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <div style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'>
                                        <ol start="3" style="margin-bottom:0cm;list-style-type: upper-alpha;margin-left:8px;">
                                            <li style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><span style='font-family:"Calibri",sans-serif;'>Data Pribadi</span></li>
                                        </ol>
                                    </div>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <ol style="list-style-type: decimal;margin-left:26px;">
                                        <li><span style='font-family:"Calibri",sans-serif;'>Anda mengetahui dan menyetujui bahwa Kami mengumpulkan informasi pribadi yang diberikan Anda saat Anda membuat akun dan profil maupun pada saat menggunakan fitur-fitur yang terdapat dalam Platform.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Informasi mengenai identitas diri yang wajib diisi oleh Anda saat membuat akun di Platform antara lain adalah:</span></li>
                                    </ol>
                                    <ol style="list-style-type: lower-roman;margin-left:48.5px;">
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>Nama lengkap sesuai kartu identitas yang berlaku (KTP atau Paspor);&nbsp;</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>Tempat dan Tanggal Lahir;</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>Jenis Kelamin;</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>Nomor telepon genggam;</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>Alamat / domisili; dan</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;font-size:11.0pt;'>Alamat Email</span></li>
                                    </ol>
                                    <ol style="list-style-type: undefined;margin-left:26px;">
                                        <li><span style='font-family:"Calibri",sans-serif;'>Anda dapat mengaktifkan atau menonaktifkan layanan pengenalan lokasi saat Anda menggunakan Platform.&nbsp;</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Apabila diperlukan, Kami dapat melakukan verifikasi langsung kepada Anda tentang data diri yang telah Anda sampaikan melalui Platform.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Informasi yang Anda berikan adalah akurat dan benar.</span></li>
                                    </ol>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <div style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'>
                                        <ol start="4" style="margin-bottom:0cm;list-style-type: upper-alpha;margin-left:8px;">
                                            <li style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><span style='font-family:"Calibri",sans-serif;'>Data <em><span style='font-family:"Calibri",sans-serif;'>Chat</span></em>, <em><span style='font-family:"Calibri",sans-serif;'>Video Call</span></em> dan <em><span style='font-family:"Calibri",sans-serif;'>Voice Call&nbsp;</span></em>Pada Fitur Chat dengan Dokter&nbsp;</span></li>
                                        </ol>
                                    </div>
                                    <p style='margin-right:0cm;margin-left:18.0pt;font-size:16px;font-family:"Times New Roman",serif;margin-top:0cm;margin-bottom:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>Untuk kenyamanan Anda dalam berinteraksi dengan Dokter, tersedia layanan <em><span style='font-family:"Calibri",sans-serif;'>chat</span></em> (yang mana Anda juga dapat mengirimkan gambar kepada dokter yang berkaitan dengan kondisi medis),<em><span style='font-family:"Calibri",sans-serif;'>&nbsp;video call</span></em> dalam Platform. Anda mengetahui dan menyetujui bahwa untuk keperluan <em><span style='font-family:"Calibri",sans-serif;'>review</span></em>, layanan <em><span style='font-family:"Calibri",sans-serif;'>video call</span></em> dan <em><span style='font-family:"Calibri",sans-serif;'>voice call</span></em> akan secara otomatis direkam dan <em><span style='font-family:"Calibri",sans-serif;'>chat history</span></em> juga akan disimpan.</span></p>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <div style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'>
                                        <ol start="5" style="margin-bottom:0cm;list-style-type: upper-alpha;margin-left:8px;">
                                            <li style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><span style='font-family:"Calibri",sans-serif;'>Koneksi Anda Ke Platform Lain</span></li>
                                        </ol>
                                    </div>
                                    <p style='margin-right:0cm;margin-left:18.0pt;font-size:16px;font-family:"Times New Roman",serif;margin-top:0cm;margin-bottom:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>Platform dapat memuat tautan menuju platform milik pihak ketiga (&ldquo;Platform Pihak Ketiga&rdquo;) dan konten pihak ketiga (&ldquo;Konten Pihak Ketiga&rdquo;). Untuk keamanan Anda, Anda perlu mempelajari dan membaca dengan hati-hati kebijakan penanganan informasi pribadi yang berlaku di Platform Pihak Ketiga dan/atau Konten Pihak Ketiga.</span></p>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <div style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'>
                                        <ol start="6" style="margin-bottom:0cm;list-style-type: upper-alpha;margin-left:8px;">
                                            <li style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><span style='font-family:"Calibri",sans-serif;'>Hukum Yang Berlaku</span></li>
                                        </ol>
                                    </div>
                                    <p style='margin-right:0cm;margin-left:18.0pt;font-size:16px;font-family:"Times New Roman",serif;margin-top:0cm;margin-bottom:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>Kebijakan Privasi ini diatur berdasarkan hukum Negara Republik Indonesia dan Anda diwajibkan tunduk kepada semua peraturan yang berlaku di Republik Indonesia.</span></p>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <div style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'>
                                        <ol start="7" style="margin-bottom:0cm;list-style-type: upper-alpha;margin-left:8px;">
                                            <li style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><span style='font-family:"Calibri",sans-serif;'>Upaya Pengamanan</span></li>
                                        </ol>
                                    </div>
                                    <p style='margin-right:0cm;margin-left:0cm;font-size:16px;font-family:"Times New Roman",serif;margin:0cm;text-align:justify;vertical-align:baseline;'><span style='font-size:15px;font-family:"Calibri",sans-serif;'>&nbsp;</span></p>
                                    <ol style="list-style-type: decimal;margin-left:26px;">
                                        <li><span style='font-family:"Calibri",sans-serif;'>Kami akan berupaya memastikan bahwa informasi yang Anda berikan kepada Kami aman dan tidak dapat digunakan oleh pihak-pihak yang tidak bertanggung jawab. Untuk keamanan data Anda, Kami sangat menyarankan agar Anda selalu memperbarui Platform dan perangkat lunak anda serta tidak mengungkapkan kata sandi anda kepada pihak manapun.</span></li>
                                        <li><span style='font-family:"Calibri",sans-serif;'>Anda dengan ini setuju bahwa Kami dapat menyimpan Data Pribadi pada server yang terletak di pusat data yang ditunjuk oleh Kami. Pemanfaatan Data Pribadi sehubungan dengan penggunaan Platform akan terus diatur oleh Kebijakan Privasi ini sesuai dengan peraturan perundangan-undangan yang berlaku di Republik Indonesia.&nbsp;</span></li>
                                    </ol>
                                </div>
                                <hr>
                                <!-- <input type="checkbox" value="" id="tac_checkbox"> <label style="font-size: 14px;" for="toc_checkbox">Saya menyetujui syarat dan ketentuan penggunaan</label> -->
                                <div class="flex">
                                    <div>
                                        <button type="button" style="width:100% !important;" class="btn btn-simpan-sm" id="simpan_toc">Setuju</button>
                                    </div>
                                    <div>
                                        <button type="button" style="width:100% !important;" class="btn btn-batal-sm mt-2" id="batal_toc">Batalkan</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if ($this->session->flashdata('msg')) {
    echo "<script>alert('" . $this->session->flashdata('msg') . "')</script>";
} ?>
<?php echo $this->session->flashdata('msg_2') ? $this->session->flashdata('msg_2') : ''; ?>
<?php if ($this->session->flashdata('msg_pmbyrn')) {
    echo "<script>alert('" . $this->session->flashdata('msg_pmbyrn') . "')</script>";
} ?>

<script>
    function openModalAndRedirect(url,spinner) {
        $('#'+spinner).show();

        const form = new FormData();
    form.append('userId', <?= $this->session->userdata("id_user")  ?>);
        axios.post('<?= config_item('pg_api') ?>/owlexa/Api/plafonCheck', form)
          .then(function (response) {
             $('#'+spinner).hide();
            if(response.data.data < 1000000)
            {
                alert('Tidak dapat melakukan pendaftaran konsultasi karena plafon tidak mencukupi, silahkan cek plafon anda kembali');
                return false;
            }

            $('#tac_modal_daftar').modal('show');
                $("#simpan_toc").on("click", function() {
                    window.location.href = url;
                });
                $("#batal_toc").on("click", function() {
                    $('#tac_modal_daftar').modal('hide');
                });
              
            })
          .catch(function (error) {
                $('#'+spinner).hide();
            alert('Tidak dapat terhubung ke endpoint payment. ');
          });
      
    }
    $(document).ready(function() {
        $('#toc_body').scroll(function(e) {
            if ($(this).scrollTop() + $(this).innerHeight() >= $(this)[0].scrollHeight) {
                $('#toc_checkbox').prop('disabled', false);
            }
        });
        $('#toc_checkbox').change(function(e) {
            if (this.checked) {
                $('#simpan_toc').prop('disabled', false);
                $('#simpan_toc').removeClass('btn-secondary').addClass('btn-primary');
            } else {
                $('#simpan_toc').prop('disabled', true);
                $('#simpan_toc').removeClass('btn-primary').addClass('btn-secondary');
            }
        });
    });
</script>

<script>
    function poli_onchange() {
        location.href = "<?php echo base_url() ?>pasien/Pendaftaran?poli=" + document.getElementById('poli').value + "&hari=" + document.getElementById('hari').value;
    }

    function hari_onchange() {
        location.href = "<?php echo base_url() ?>pasien/Pendaftaran?poli=" + document.getElementById('poli').value + "&hari=" + document.getElementById('hari').value;
    }
</script>