<div class="page-wrapper">
  <div class="content">
      <div class="row mb-3">
          <div class="col-sm-5 col-12">
              <h4 class="page-title">Pengingat Jadwal</h4>
          </div>
          <div class="col-sm-7 col-12">
            <nav aria-label="">
                <ol class="breadcrumb" style="background-color: whitesmoke; float: right">
                    <li class="breadcrumb-item"><a href="<?php echo base_url('admin/admin');?>">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Pengingat Jadwal</li>
                </ol>
            </nav>
          </div>
      </div>
        <div class="table-responsive">
            <table class="table table-border table-hover custom-table mb-0" id="table_pengingat_jadwal">
            <thead>
                <tr>
                <th>Ingatkan Pada</th>
                <th>Ingatkan Setiap</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
            <tfoot>
                <tr>
        `        <th>Ingatkan Pada</th>
                <th>Ingatkan Setiap</th>`
                </tr>
            </tfoot>
            </table>
          </div>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->