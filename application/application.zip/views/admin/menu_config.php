
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-lg-6 col-6">
            <!-- small box -->
            <a href="<?php echo base_url('admin/Config/nominal') ?>">
            <div class="small-box card-menu bg-dark-blue-menu pd-card-menu">
              <div class="inner">
                <h5 class="text-white">Nominal</h5>
              </div>
              <div class="icon">
                <i class="fas fa-user-alt"></i>
              </div>
            </div></a>
          </div>
          <!-- ./col -->
           <div class="col-lg-6 col-6">
            <a href="<?php echo base_url('admin/Config/poli') ?>">
            <div class="small-box card-menu bg-dark-blue-menu pd-card-menu">
              <div class="inner">
                <h5 class="text-white">Poli</h5>
              </div>
              <div class="icon">
                <i class="fas fa-clinic-medical"></i>
              </div>
            </div>
            </a>
          </div>
        </div>
        <!-- </div> -->
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>    <!-- /.content -->
