
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-lg-6 col-6">
            <!-- small box -->
            <a href="<?php echo base_url('admin/Obat/manage_obat') ?>">
            <div class="small-box card-menu bg-dark-blue-menu pd-card-menu">
              <div class="inner">
                <h5 class="text-white">Obat</h5>
              </div>
              <div class="icon">
                <i class="fa fa-plus-circle"></i>
              </div>
            </div></a>
          </div>
          <!-- ./col -->
           <div class="col-lg-6 col-6">
            <a href="<?php echo base_url('admin/Obat/manage_kategori_obat') ?>">
            <div class="small-box card-menu bg-dark-blue-menu pd-card-menu">
              <div class="inner">
                <h5 class="text-white">Kategori Obat</h5>
              </div>
              <div class="icon">
                <i class="fa fa-plus-square"></i>
              </div>
            </div>
            </a>
          </div>
        </div>
        <!-- </div> -->
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>    <!-- /.content -->
