<script src="<?php echo base_url('assets/adminLTE/plugins/jquery/jquery-2.1.4.min.js')?>"></script>
<script src="<?php echo base_url('assets/adminLTE/plugins/datatables/jquery.datatables.min.js')?>"></script>
<script src="<?php echo base_url('assets/adminLTE/plugins/datatables/dataTables.bootstrap.js')?>"></script>