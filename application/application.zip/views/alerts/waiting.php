<div id="alert-waiting" class="hide animated bounceInDown alert-fixed alert alert-info alert-dismissible fade in"
     role="alert">
    <h4 class="animated flash infinite">Please Wait ...</h4>
    <p>You make a call to <span id="receiver"><strong>Admin</strong></span></p>

</div>