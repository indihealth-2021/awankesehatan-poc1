
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-lg-6 col-6">
            <!-- small box -->
            <a href="<?php echo base_url('admin/History') ?>">
            <div class="small-box card-menu bg-dark-blue-menu pd-card-menu">
              <div class="inner">
                <h5 class="text-white">History Log</h5>
              </div>
              <div class="icon">
                <i class="fas fa-history"></i>
              </div>
            </div></a>
          </div>
          <!-- ./col -->
          <div class="col-lg-6 col-6">
            <!-- small box -->
            <a href="<?php echo base_url('admin/LogActivity') ?>">
            <div class="small-box card-menu bg-dark-blue-menu pd-card-menu">
              <div class="inner">
                <h5 class="text-white">Log Activity</h5>
              </div>
              <div class="icon">
                <i class="fas fa-history"></i>
              </div>
            </div>
            </a>
          </div>
        </div>
        <!-- </div> -->
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>    <!-- /.content -->
