<div id="alert-calling" class="hide animated bounceInDown alert-fixed alert alert-info alert-dismissible fade in"
     role="alert">
    <h4>Calling ...</h4>
    <p>You have a call from <span id="caller"><strong>Admin</strong></span></p>
    <p>
        <button type="button" class="btn btn-success animated flash infinite" id="btn-answer">Answer</button>
        <!--        <button type="button" class="btn btn-default">Hang Up</button>-->
    </p>
</div>