<div class="page-wrapper">
            <div class="content">
                <div class="row mb-5">
          <div class="col-sm-5 col-12">
              <h4 class="page-title">Assesment</h4>
          </div>
          <div class="col-sm-7 col-12">
            <nav aria-label="">
                <ol class="breadcrumb" style="background-color: whitesmoke; float: right">
                    <li class="breadcrumb-item"><a href="<?php echo base_url('pasien/pasien');?>">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Assesment</li>
                </ol>
            </nav>
          </div>
      	<div class="col-md-8 offset-lg-2 mt-5">
      		<div class="card-box" ">
		  <div class="card-title">
		    Perhatian !!!
		  </div>
		  <div class="card-body">
		    <h5 class="card-title">Anda belum memiliki jadwal konsultasi</h5>
		    <p class="card-text">Jika anda sudah mendaftar, tunggu pembayaran sampai diverifikasi oleh Admin.</p>
		    <a href="<?php echo base_url('pasien/Pendaftaran?poli=&hari=all') ?>" class="btn btn-primary mt-3">Daftar Sekarang</a>
		  </div>
      </div>
      	</div>
     </div>
    </div>
   </div>